# Oracle Eye Hospital - SEO Landing Page Templates

This bundle contains the 3 standard template files for creating high-performing SEO landing pages:

1. **Banner.jsx**:
   - Hero banner with 30% compressed height, mobile-optimized order (Image before Title on phones).
   - Side-by-side buttons on mobile (Book Appointment & Call Now in 1 row).
   - Single-row 3-column clinical badges (Procedure Duration, Surgical Technique, Payment & TPA).

2. **Content.jsx**:
   - Two-column layout with responsive article blocks.
   - Sticky sidebar with Appointment form + Table of Contents (TOC positioned below appointment form).
   - Comparison tables, FAQ accordion, Doctor profiles, and Bottom CTA.

3. **page.jsx**:
   - Next.js App Router Server Component with dynamic SEO metadata.
   - Fully automated JSON-LD Schema integration (Hospital, Physician, FAQ, Breadcrumb, MedicalProcedure).

## How to Use:
1. Create a new folder under `src/app/(seo_pages)/[your-target-slug]/`
   Example: `src/app/(seo_pages)/lasik-laser-surgery-in-moradabad/`
2. Extract or copy `Banner.jsx`, `Content.jsx`, and `page.jsx` into that folder.
3. Replace `[Your Procedure Name]` and slug in `page.jsx`, `Banner.jsx`, and `Content.jsx`.
4. Your new landing page is immediately live and accessible at `http://localhost:3000/[your-target-slug]`!