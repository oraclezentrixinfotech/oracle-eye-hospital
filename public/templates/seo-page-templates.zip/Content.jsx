"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Phone,
  Calendar,
  CheckCircle2,
  ChevronDown,
  ListOrdered,
  Award,
  Clock,
  Sparkles,
} from "lucide-react";
import AppointmentForm from "../../components/AppointmentForm";

const SECTIONS = [
  { id: "overview", heading: "1. Overview & Clinical Significance" },
  { id: "symptoms-candidacy", heading: "2. Symptoms & When to Seek Consultation" },
  { id: "procedure-technology", heading: "3. Advanced Surgical Procedure & Technology" },
  { id: "comparison-table", heading: "4. Clinical Options & Technique Comparison" },
  { id: "recovery-aftercare", heading: "5. Recovery Timeline & Post-Operative Care" },
  { id: "cost-insurance", heading: "6. Cost Transparency & Cashless Insurance (TPA)" },
  { id: "faqs", heading: "7. Frequently Asked Questions" },
];

const FAQS = [
  {
    question: "How long does the procedure take?",
    answer: "The advanced procedure typically takes only 15 to 20 minutes under topical drop anesthesia with same-day walk-in and discharge.",
  },
  {
    question: "Is the procedure painful?",
    answer: "No. Advanced numbing eye drops ensure the surgery is virtually painless without any needles or injections.",
  },
  {
    question: "Does insurance cover this treatment?",
    answer: "Yes, Oracle Eye Hospital is empanelled with major TPAs, Ayushman Bharat (PM-JAY), and government panels for seamless cashless treatment.",
  },
];

export default function Content() {
  const [activeSection, setActiveSection] = useState("overview");
  const [tocOpen, setTocOpen] = useState(true);
  const [openFaq, setOpenFaq] = useState(0);
  const rowRef = useRef(null);

  const helpline = "+91 8006803111";
  const cleanPhone = helpline.replace(/[^0-9+]/g, "");

  useEffect(() => {
    const handleScroll = () => {
      const scrollPos = window.scrollY + 200;
      for (const sec of SECTIONS) {
        const el = document.getElementById(sec.id);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sec.id);
            break;
          }
        }
      }
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <section className="seo-section py-5">
        <div className="container">
          <div className="row g-4 g-lg-5 seo-content-row" ref={rowRef}>
            {/* Left Column: Comprehensive Article */}
            <div className="col-lg-8">
              <article className="seo-article-container">
                {/* 1. Overview */}
                <div className="seo-article-block" id="overview">
                  <h2 className="seo-article-h2">1. Overview &amp; Clinical Significance</h2>
                  <p className="seo-article-p">
                    Write your clinical overview here. Introduce the condition, treatment methods, and why early diagnosis is critical for preserving vision.
                  </p>
                  <p className="seo-article-p">
                    Explain how modern micro-incision surgical techniques have made this outpatient procedure stitchless, injection-free, and pain-free.
                  </p>
                </div>

                {/* 2. Symptoms */}
                <div className="seo-article-block" id="symptoms-candidacy">
                  <h2 className="seo-article-h2">2. Symptoms &amp; When to Seek Consultation</h2>
                  <p className="seo-article-p">
                    Detail the common warning signs patients should monitor before scheduling their comprehensive eye evaluation:
                  </p>
                  <ul className="seo-checklist">
                    <li><CheckCircle2 size={18} color="#137c8b" /> <span>Progressive blurriness or cloudy vision.</span></li>
                    <li><CheckCircle2 size={18} color="#137c8b" /> <span>Difficulty driving at night due to glare and halos around headlights.</span></li>
                    <li><CheckCircle2 size={18} color="#137c8b" /> <span>Frequent changes in eyeglass or contact lens prescription.</span></li>
                    <li><CheckCircle2 size={18} color="#137c8b" /> <span>Faded or yellowed perception of bright colors.</span></li>
                  </ul>
                </div>

                {/* 3. Technology */}
                <div className="seo-article-block" id="procedure-technology">
                  <h2 className="seo-article-h2">3. Advanced Surgical Procedure &amp; Technology</h2>
                  <p className="seo-article-p">
                    Describe the cutting-edge technology platforms utilized at Oracle Eye Hospital, such as robotic precision lasers and US-FDA approved vision systems.
                  </p>
                </div>

                {/* 4. Comparison Table */}
                <div className="seo-article-block" id="comparison-table">
                  <h2 className="seo-article-h2">4. Clinical Options &amp; Technique Comparison</h2>
                  <div className="table-responsive my-3">
                    <table className="table table-bordered table-striped seo-content-table">
                      <thead>
                        <tr>
                          <th>Parameter</th>
                          <th>Standard Technique</th>
                          <th>Advanced Robotic Precision</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><strong>Incision Size</strong></td>
                          <td>2.8 mm – 3.2 mm</td>
                          <td>1.8 mm – 2.2 mm (Micro-Incision)</td>
                        </tr>
                        <tr>
                          <td><strong>Visual Recovery</strong></td>
                          <td>3 to 7 Days</td>
                          <td>24 to 48 Hours</td>
                        </tr>
                        <tr>
                          <td><strong>Stitches Required</strong></td>
                          <td>None</td>
                          <td>None (Self-sealing)</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* 5. Recovery */}
                <div className="seo-article-block" id="recovery-aftercare">
                  <h2 className="seo-article-h2">5. Recovery Timeline &amp; Post-Operative Care</h2>
                  <p className="seo-article-p">
                    Explain what patients can expect on the day of procedure, within the first 24 hours, and during long-term visual stabilization.
                  </p>
                </div>

                {/* 6. Cost & Insurance */}
                <div className="seo-article-block" id="cost-insurance">
                  <h2 className="seo-article-h2">6. Cost Transparency &amp; Cashless Insurance (TPA)</h2>
                  <p className="seo-article-p">
                    At Oracle Eye Hospital, we maintain 100% pricing transparency with zero hidden charges. Our cashless insurance helpdesk coordinates with all leading TPAs and PM-JAY.
                  </p>
                </div>

                {/* 7. FAQs */}
                <div className="seo-article-block" id="faqs">
                  <h2 className="seo-article-h2">7. Frequently Asked Questions</h2>
                  <div className="seo-faq-accordion">
                    {FAQS.map((faq, idx) => (
                      <div key={idx} className="seo-faq-item">
                        <button
                          type="button"
                          className="seo-faq-question"
                          onClick={() => setOpenFaq(openFaq === idx ? -1 : idx)}
                          aria-expanded={openFaq === idx}
                        >
                          <span>{faq.question}</span>
                          <ChevronDown
                            size={18}
                            className={`seo-faq-icon ${openFaq === idx ? "open" : ""}`}
                          />
                        </button>
                        {openFaq === idx && (
                          <div className="seo-faq-answer">
                            <p>{faq.answer}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </article>
            </div>

            {/* Right Column: Sticky Sidebar with Appointment Form & TOC */}
            <div className="col-lg-4">
              <aside className="seo-sidebar-sticky" id="sidebar-appointment">
                {/* 1. Book an Appointment Card */}
                <div className="seo-sidebar-form-box">
                  <div className="seo-sidebar-form-header">
                    <span className="badge bg-warning text-dark mb-1">Direct OPD Booking</span>
                    <h3>Schedule Your Consultation</h3>
                    <p>Meet our senior ophthalmologists at Oracle Eye Hospital.</p>
                  </div>
                  <div className="seo-sidebar-form-body">
                    <AppointmentForm />
                  </div>
                </div>

                {/* 2. Interactive Table of Contents (Positioned below Appointment Card) */}
                <div className="seo-sidebar-card mb-4 mt-4">
                  <div className="seo-sidebar-toc-header" onClick={() => setTocOpen(!tocOpen)}>
                    <h4>
                      <ListOrdered size={16} color="#137c8b" />
                      <span>Table of Contents</span>
                    </h4>
                    <span className="seo-sidebar-toc-toggle">
                      {tocOpen ? "Hide" : "Show"}
                      <ChevronDown
                        size={13}
                        style={{
                          transform: tocOpen ? "rotate(180deg)" : "rotate(0deg)",
                          transition: "transform 0.2s ease",
                        }}
                      />
                    </span>
                  </div>

                  {tocOpen && (
                    <div className="seo-sidebar-toc-content">
                      <ul className="seo-sidebar-toc-list">
                        {SECTIONS.map((sec) => (
                          <li key={sec.id}>
                            <a
                              href={`#${sec.id}`}
                              className={activeSection === sec.id ? "active" : ""}
                            >
                              {sec.heading}
                            </a>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* Quick Helpline Card */}
                <div className="seo-sidebar-card seo-sidebar-emergency mt-3">
                  <div className="d-flex align-items-center gap-3">
                    <div className="seo-emergency-icon">
                      <Phone size={24} color="#ffffff" />
                    </div>
                    <div>
                      <span className="text-white-50 small d-block">24/7 Helpline &amp; TPA Desk</span>
                      <a href={`tel:${cleanPhone}`} className="fw-bold text-white text-decoration-none">
                        {helpline}
                      </a>
                    </div>
                  </div>
                </div>
              </aside>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section className="seo-bottom-cta-section py-5">
        <div className="container">
          <div className="seo-bottom-cta-body text-center p-5 rounded-4">
            <h2 className="text-white mb-3">Protect Your Vision With Trusted Specialists</h2>
            <p className="text-white-50 max-w-2xl mx-auto mb-4">
              Schedule your appointment at Moradabad&apos;s foremost NABH-aligned eye care hospital.
            </p>
            <div className="d-flex flex-wrap gap-3 justify-content-center">
              <a href="#sidebar-appointment" className="seo-btn-appointment">
                <Calendar size={18} />
                <span>Book Appointment Online</span>
              </a>
              <a href={`tel:${cleanPhone}`} className="seo-btn-call">
                <Phone size={18} color="#e8a33d" />
                <span>Call Helpline: {helpline}</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}