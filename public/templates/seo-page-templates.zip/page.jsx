import Banner from "./Banner";
import Content from "./Content";
import {
  generateHospitalSchema,
  generatePhysicianSchema,
  generateFAQSchema,
  generateBreadcrumbSchema,
  generateProcedureSchema,
  PRIMARY_DOCTORS,
} from "../_lib/schema";

// EDIT THESE CONSTANTS FOR YOUR TARGET KEYWORD & LOCATION
const PAGE_SLUG = "your-procedure-slug-in-moradabad";
const PAGE_URL = `https://www.oracleeyehospital.com/${PAGE_SLUG}`;

// 50–60 characters, keyword first, ends with "| Oracle Eye Hospital"
const PAGE_TITLE = "[Your Procedure Name] in Moradabad | Oracle Eye Hospital";

// 140–160 characters, keyword + CTA
const PAGE_DESCRIPTION =
  "Looking for [procedure name] in Moradabad? Oracle Eye Hospital offers stitchless surgical precision, experienced eye specialists & cashless insurance. Book today!";

export const metadata = {
  title: PAGE_TITLE,
  description: PAGE_DESCRIPTION,
  alternates: {
    canonical: PAGE_URL,
  },
  openGraph: {
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    url: PAGE_URL,
    siteName: "Oracle Eye Hospital",
    locale: "en_IN",
    type: "website",
    images: [
      {
        url: "https://www.oracleeyehospital.com/Assets/img/services/Cataract-Service.png",
        width: 1200,
        height: 630,
        alt: `${PAGE_TITLE} - Oracle Eye Hospital`,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: PAGE_TITLE,
    description: PAGE_DESCRIPTION,
    images: ["https://www.oracleeyehospital.com/Assets/img/services/Cataract-Service.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

const FAQS_DATA = [
  {
    question: "How long does the procedure take?",
    answer: "The advanced procedure typically takes only 15 to 20 minutes under topical drop anesthesia with same-day walk-in and discharge.",
  },
  {
    question: "Is the procedure painful?",
    answer: "No. Advanced numbing eye drops ensure the surgery is virtually painless without any needles or injections.",
  },
  {
    question: "Does insurance cover this treatment?",
    answer: "Yes, Oracle Eye Hospital is empanelled with major TPAs, Ayushman Bharat (PM-JAY), and government panels for seamless cashless treatment.",
  },
];

export default function SeoLandingPage() {
  const hospitalSchema = generateHospitalSchema();
  const physicianSchema = generatePhysicianSchema(PRIMARY_DOCTORS[0]);
  const faqSchema = generateFAQSchema(FAQS_DATA);
  const breadcrumbSchema = generateBreadcrumbSchema([
    { name: "Home", url: "https://www.oracleeyehospital.com" },
    { name: "Services", url: "https://www.oracleeyehospital.com/services" },
    { name: "[Your Procedure Name]", url: PAGE_URL },
  ]);
  const procedureSchema = generateProcedureSchema({
    name: "[Your Procedure Name] in Moradabad",
    description: PAGE_DESCRIPTION,
    url: PAGE_URL,
    bodyLocation: "Eye",
  });

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(hospitalSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(physicianSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(procedureSchema) }}
      />

      <main className="seo-landing-page">
        <Banner />
        <Content />
      </main>
    </>
  );
}